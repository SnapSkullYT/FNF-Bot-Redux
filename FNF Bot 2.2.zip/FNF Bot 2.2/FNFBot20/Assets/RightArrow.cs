﻿using System.Drawing;
using System.Windows.Forms;

namespace FNFDataManager.Assets
{
    public partial class RightArrow : UserControl
    {
        public RightArrow()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;

        }
    }
}