﻿using System.Drawing;
using System.Windows.Forms;

namespace FNFDataManager.Assets
{
    public partial class DownArrow : UserControl
    {
        public DownArrow()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;

        }

  
    }
}